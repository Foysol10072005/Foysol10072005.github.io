# DrivePlyr
Google Drive Proxy Video Player with Many Powerful HTML5 Players Hidden ID and Many Features 🚀


![drive-logo](https://user-images.githubusercontent.com/66713844/189491013-27a5bc30-6057-4e08-b66b-d5184f20060d.png)

- https://driveplyr.sh20raj.repl.co
- https://videoplyr.sh20raj.repl.co
